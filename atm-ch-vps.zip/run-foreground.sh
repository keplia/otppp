#!/usr/bin/env bash
# Run atm-ch in the foreground (loads ./atm-ch.env). CTRL-C to stop.
#   bash run-foreground.sh              # live
#   bash run-foreground.sh --dry --seed # test (print matches, no send)
#   bash run-foreground.sh --test       # verify Telegram bot
set -euo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")"
if [ -f atm-ch.env ]; then set -a; . ./atm-ch.env; set +a; fi
exec node atm-ch.mjs "$@"
