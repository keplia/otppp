// atm-ch.mjs — Atmosphere Sms CHANNEL scraper -> Telegram forwarder
// ---------------------------------------------------------------------------
// SOURCE : public Telegram channel  https://t.me/s/atmospheresmscod  (web preview,
//          no auth, no token needed to READ). Polled every second.
// FILTER : default = merchant "BYTEPLUS" (ANY card ending). Only the NEWEST post
//          is checked each poll (Jack's spec 2026-11-12).
// DEST   : Jack's bot -> Jack's channel (TG_TOKEN / TG_CHAT).
//
// Usage:
//   node atm-ch.mjs                        # live: poll 1s, forward matches
//   node atm-ch.mjs --dry                  # detect + print matches, don't send
//   node atm-ch.mjs --seed                 # also forward matches already in backlog
//   node atm-ch.mjs --all                  # forward EVERY Visa Secure OTP
//   node atm-ch.mjs --merchant BYTEPLUS --last4 1620
//   node atm-ch.mjs --test                 # verify bot + channel (send then delete)
//   node atm-ch.mjs --channel atmospheresmscod
// ---------------------------------------------------------------------------
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const HERE = path.dirname(fileURLToPath(import.meta.url));

const CFG = {
  channel: process.env.ATM_SRC_CHANNEL || "atmospheresmscod",
  telegramToken: process.env.TG_TOKEN || "9212157388:AAG1Qmf_p3Bvn1t9NpCsp2mSzr1QcbqqsBk",
  telegramChat: process.env.TG_CHAT || "-1004497745551",
  intervalMs: 1000,
  httpTimeoutMs: 20000,
  stateFile: path.join(HERE, "state-ch.json"),
  logFile: path.join(HERE, "atm-ch.log"),
  ua: "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
};

// Default (Jack 2026-11-12): match merchant BYTEPLUS, ANY card ending.
// Only the NEWEST post is checked each poll.
// Env overrides: ATM_MERCHANT ("" = any), ATM_LAST4, ATM_ALL=1, ATM_INTERVAL(ms).
let FILTER = {
  merchant: process.env.ATM_MERCHANT === "" ? null : (process.env.ATM_MERCHANT || "BYTEPLUS"),
  last4: process.env.ATM_LAST4 || null,
  all: process.env.ATM_ALL === "1",
};
let DRY = false, SEED = false, TEST = false;

const argv = process.argv.slice(2);
const getArg = (n, d) => { const i = argv.indexOf(n); return i >= 0 && argv[i + 1] && !argv[i + 1].startsWith("--") ? argv[i + 1] : d; };
if (argv.includes("--dry")) DRY = true;
if (argv.includes("--seed")) SEED = true;
if (argv.includes("--test")) TEST = true;
if (argv.includes("--all")) FILTER = { merchant: null, last4: null, all: true };
if (argv.includes("--merchant")) FILTER.merchant = getArg("--merchant");
if (argv.includes("--last4")) FILTER.last4 = getArg("--last4");
if (argv.includes("--no-merchant")) FILTER.merchant = null;
if (argv.includes("--no-last4")) FILTER.last4 = null;
if (argv.includes("--channel")) CFG.channel = getArg("--channel");
if (argv.includes("--token")) CFG.telegramToken = getArg("--token");
if (argv.includes("--chat")) CFG.telegramChat = getArg("--chat");
CFG.intervalMs = parseInt(getArg("--interval", process.env.ATM_INTERVAL || String(CFG.intervalMs)), 10) || 1000;

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const escapeRe = (s) => String(s).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

// ----------------------------- SINGLE INSTANCE ----------------------------
// Prevents two copies running at once (=> duplicate forwards). If a live
// instance already holds the lock, this one exits.
const LOCK_FILE = path.join(HERE, ".atm-ch.lock");
function acquireLock() {
  try {
    const cur = parseInt(fs.readFileSync(LOCK_FILE, "utf8"), 10);
    if (cur && cur !== process.pid) {
      try { process.kill(cur, 0); log(`another instance already running (pid ${cur}) -> exiting`); process.exit(0); }
      catch { /* stale lock */ }
    }
  } catch { /* no lock yet */ }
  try { fs.writeFileSync(LOCK_FILE, String(process.pid)); } catch {}
}
function releaseLock() { try { if (parseInt(fs.readFileSync(LOCK_FILE, "utf8"), 10) === process.pid) fs.unlinkSync(LOCK_FILE); } catch {} }

function log(...a) {
  const line = `[${new Date().toISOString()}] ${a.join(" ")}`;
  console.log(line);
  try { fs.appendFileSync(CFG.logFile, line + "\n"); } catch {}
}

// ----------------------------- HTTP ---------------------------------------
async function httpText(url, opts = {}) {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), CFG.httpTimeoutMs);
  try {
    const r = await fetch(url, { ...opts, signal: ctrl.signal, headers: { "User-Agent": CFG.ua, "Accept-Language": "en-US,en;q=0.9", ...(opts.headers || {}) } });
    return { status: r.status, text: await r.text() };
  } finally { clearTimeout(t); }
}

async function tg(method, body) {
  for (let attempt = 0; attempt < 4; attempt++) {
    const ctrl = new AbortController();
    const t = setTimeout(() => ctrl.abort(), CFG.httpTimeoutMs);
    let j = null;
    try {
      const r = await fetch(`https://api.telegram.org/bot${CFG.telegramToken}/${method}`, {
        method: "POST", signal: ctrl.signal,
        headers: { "Content-Type": "application/json" }, body: JSON.stringify(body),
      });
      j = await r.json().catch(() => null);
    } catch (e) { j = { ok: false, description: e.message }; }
    finally { clearTimeout(t); }
    if (j && j.ok) return j.result;
    if (j && j.error_code === 429) { const w = (j.parameters?.retry_after || 2) * 1000; log(`tg 429 wait ${w}ms`); await sleep(w); continue; }
    throw new Error(`telegram ${method} failed: ${JSON.stringify(j)}`);
  }
  throw new Error("telegram retries exhausted");
}

// ----------------------------- PARSE --------------------------------------
function decodeEntities(s) {
  return s
    .replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"')
    .replace(/&#0?39;/g, "'").replace(/&apos;/g, "'").replace(/&nbsp;/g, " ")
    .replace(/&#(\d+);/g, (_, d) => String.fromCodePoint(+d))
    .replace(/&amp;/g, "&");
}

// Extract [{id, text}] from a t.me/s/<channel> preview page.
function parseChannel(html) {
  const out = [];
  // each message block starts with data-post="<channel>/<id>"
  const blocks = html.split('tgme_widget_message ');
  const rePost = new RegExp('data-post="' + escapeRe(CFG.channel) + '\\/(\\d+)"');
  for (const blk of blocks) {
    const mp = rePost.exec(blk);
    if (!mp) continue;
    const id = parseInt(mp[1], 10);
    // text div
    const mt = /class="tgme_widget_message_text[^"]*"[^>]*>([\s\S]*?)<\/div>/.exec(blk);
    let text = "";
    if (mt) {
      let inner = mt[1].replace(/<br\s*\/?>/gi, "\n").replace(/<[^>]+>/g, "");
      text = decodeEntities(inner).replace(/[ \t]+\n/g, "\n").trim();
    }
    out.push({ id, text });
  }
  // dedup by id, ascending
  const seen = new Map();
  for (const m of out) seen.set(m.id, m);
  return [...seen.values()].sort((a, b) => a.id - b.id);
}

// Pull the "Use code ..." line (the real OTP text) out of the channel post.
function extractPesan(text) {
  // Prefer the sentence after "Pesan:"
  const i = text.indexOf("Pesan:");
  const seg = i >= 0 ? text.slice(i + "Pesan:".length) : text;
  const m = /Use code[^\n]*/i.exec(seg) || /Use code[^\n]*/i.exec(text);
  return m ? m[0].trim() : (seg.trim() || text.trim());
}

// ----------------------------- MATCH --------------------------------------
function isVisaSecure(t) { return /approve your Visa Secure transaction/i.test(t); }
function match(pesan) {
  if (FILTER.all) return isVisaSecure(pesan);
  if (!isVisaSecure(pesan)) return false;
  if (FILTER.merchant && !new RegExp("to\\s+" + escapeRe(FILTER.merchant) + "\\s+with card ending", "i").test(pesan)) return false;
  if (FILTER.last4 && !new RegExp("card ending\\s+" + escapeRe(FILTER.last4) + "\\b", "i").test(pesan)) return false;
  return true;
}

// ----------------------------- STATE --------------------------------------
function loadState() { try { return JSON.parse(fs.readFileSync(CFG.stateFile, "utf8")); } catch { return { lastId: 0, sent: {} }; } }
function saveState(s) {
  s.sent = s.sent || {};
  const k = Object.keys(s.sent);
  if (k.length > 8000) k.sort((a, b) => a - b).slice(0, k.length - 8000).forEach((x) => delete s.sent[x]);
  try { fs.writeFileSync(CFG.stateFile, JSON.stringify(s)); } catch {}
}
const state = loadState();

async function forward(m) {
  const pesan = extractPesan(m.text);
  if (DRY) { log(`MATCH(dry) id=${m.id} :: ${pesan}`); return; }
  try {
    const res = await tg("sendMessage", { chat_id: CFG.telegramChat, text: pesan, disable_web_page_preview: true });
    log(`SENT id=${m.id} tg_msg=${res.message_id} :: ${pesan.slice(0, 120)}`);
    state.sent[m.id] = 1; saveState(state);
  } catch (e) { log(`SEND FAIL id=${m.id}: ${e.message}`); }
}

async function fetchChannel() {
  const url = `https://t.me/s/${CFG.channel}?embed=1&_=${Date.now()}`;
  const r = await httpText(url);
  if (r.status !== 200) throw new Error(`channel http ${r.status}`);
  return parseChannel(r.text);
}

// ----------------------------- FLOW ---------------------------------------
async function testTelegram() {
  log("test getMe ...");
  const me = await tg("getMe", {});
  log("bot:", me.username || me.first_name, "(id " + me.id + ")");
  const chat = await tg("getChat", { chat_id: CFG.telegramChat });
  log("dest chat:", chat.title || chat.username, "type:", chat.type);
  const sent = await tg("sendMessage", { chat_id: CFG.telegramChat, text: "✅ ATM-CH scraper online test (auto-delete)", disable_notification: true });
  log("test tg_msg_id:", sent.message_id);
  await sleep(1500);
  try { await tg("deleteMessage", { chat_id: CFG.telegramChat, message_id: sent.message_id }); log("test deleted"); }
  catch (e) { log("delete failed (ok if no perms):", e.message); }
}

async function main() {
  log(`Starting ATM-CH scraper | src=t.me/s/${CFG.channel} | filter merchant=${FILTER.merchant || "*"} last4=${FILTER.last4 || "*"} all=${FILTER.all} | dry=${DRY} seed=${SEED} | interval=${CFG.intervalMs}ms`);
  if (TEST) { await testTelegram(); return; }
  acquireLock();

  // baseline
  let msgs = [];
  try { msgs = await fetchChannel(); } catch (e) { log("baseline err:", e.message); }
  if (msgs.length) {
    const maxId = msgs[msgs.length - 1].id;
    if (state.lastId === 0) { state.lastId = maxId; saveState(state); log(`baseline: ${msgs.length} posts, maxId=${maxId} (history NOT forwarded${SEED ? ", seeding" : ""})`); }
    else log(`resume: lastId=${state.lastId}, channel maxId=${maxId}`);
    if (SEED) for (const m of msgs) if (m.id > 0 && match(extractPesan(m.text)) && !state.sent[m.id]) await forward(m);
  }

  let n = 0, fails = 0;
  for (;;) {
    try {
      const list = await fetchChannel();   // ascending
      fails = 0;
      // ONLY the newest post is checked (Jack's spec: "cuma pesan PALING BARU").
      const newest = list.length ? list[list.length - 1] : null;
      if (newest && newest.id > state.lastId) {
        const extra = list.filter((m) => m.id > state.lastId).length - 1;
        const pesan = extractPesan(newest.text);
        if (match(pesan)) {
          if (!state.sent[newest.id]) await forward(newest);
        } else {
          state.sent[newest.id] = 1;
        }
        state.lastId = newest.id;
        if (extra > 0) log(`note: ${extra} older post(s) skipped (only newest checked)`);
      }
      saveState(state);
    } catch (e) {
      fails++;
      if (fails <= 3 || fails % 60 === 0) log(`poll err(${fails}): ${e.message}`);
    }
    n++;
    if (n % 120 === 0) log(`heartbeat: lastId=${state.lastId} polls=${n} fails=${fails}`);
    // gentle backoff if the source is throttling/erroring
    await sleep(fails > 6 ? Math.min(CFG.intervalMs * 5, 10000) : CFG.intervalMs);
  }
}

process.on("SIGINT", () => { log("shutdown"); saveState(state); releaseLock(); process.exit(0); });
process.on("SIGTERM", () => { log("shutdown(sigterm)"); saveState(state); releaseLock(); process.exit(0); });
process.on("exit", () => releaseLock());
process.on("uncaughtException", (e) => log("uncaught:", e.message));
process.on("unhandledRejection", (e) => log("unhandled:", e && e.message));

main();
