# ATM-CH — Atmosphere Sms channel → Telegram (Ubuntu VPS)

Polls the public Telegram channel **t.me/s/atmospheresmscod** every second and forwards
**only the newest OTP that matches the filter** (default: merchant `BYTEPLUS`, ANY card
ending) to your Telegram bot → your channel.

- **Zero npm dependencies** — pure Node stdlib + built-in `fetch` (needs Node **≥ 18**).
- **Only the newest post is checked** each tick; backlog / older posts are never scanned.
- Dedup by post id (`state-ch.json`) → никогда double-send.
- Runs 24/7 via **systemd** (auto-start on boot, auto-restart on crash).

---

## 1) Upload to the VPS

From this PC (PowerShell):

```powershell
scp -r "D:\TRADING\SCALPING\tools\atm-otp\vps-package" root@YOUR_VPS_IP:/root/atm-ch
```

(or zip it and drag-drop with WinSCP / `pscp`.)

## 2) Install (on the VPS)

```bash
cd /root/atm-ch
sudo bash install.sh
```

That will: install Node 20 if missing → deploy to `/opt/atm-ch` → create a systemd
service `atm-ch` → enable + start it.

## 3) Verify

```bash
sudo systemctl status atm-ch
tail -f /opt/atm-ch/atm-ch.log
bash test-telegram.sh          # sends a test msg then deletes it
```

---

## Config — `/opt/atm-ch/atm-ch.env`

| Key | Meaning |
|-----|---------|
| `TG_TOKEN` | bot token |
| `TG_CHAT` | destination channel id (e.g. `-1004497745551`) |
| `ATM_SRC_CHANNEL` | source channel, without `@` (`atmospheresmscod`) |
| `ATM_MERCHANT` | merchant substring, case-insensitive (`BYTEPLUS`). **empty = any merchant** |
| `ATM_LAST4` | card ending (`1620`), **empty = any card ending** |
| `ATM_ALL` | `1` = forward every Visa Secure OTP (ignores merchant + last4) |
| `ATM_INTERVAL` | poll interval in ms (`1000` = 1s) |

After editing:

```bash
sudo systemctl restart atm-ch
```

Examples:
- Only card ending 1620 (any merchant): `ATM_MERCHANT=` and `ATM_LAST4=1620`
- Every OTP: `ATM_ALL=1`

---

## Files

| File | Purpose |
|------|---------|
| `atm-ch.mjs` | the scraper (Node ≥ 18) |
| `atm-ch.env` | configuration |
| `install.sh` | installer → systemd service |
| `uninstall.sh` | remove the service |
| `run-foreground.sh` | run in foreground (debug): `bash run-foreground.sh --dry` |
| `test-telegram.sh` | verify bot + channel |

## Operations

```bash
sudo systemctl status atm-ch        # state
sudo systemctl restart atm-ch       # restart
sudo systemctl stop atm-ch          # stop
sudo journalctl -u atm-ch -f        # live systemd log
tail -f /opt/atm-ch/atm-ch.log      # app log (SENT / heartbeat / errors)
```

## Troubleshooting

- **No messages in channel** → check `tail -f /opt/atm-ch/atm-ch.log` for `SENT` / `heartbeat`.
  Heartbeat prints every ~2 min. `poll err` lines = transient network; it retries.
- **`telegram getMe failed ... 401`** → wrong `TG_TOKEN`.
- **No SENT for a matching OTP** → confirm `ATM_MERCHANT` / `ATM_LAST4`; the channel must
  be public so `https://t.me/s/<channel>` loads.
- **Node too old** → re-run `install.sh` (installs Node 20) or `apt install nodejs`.
- Reset the cursor (re-check from now): `rm /opt/atm-ch/state-ch.json && sudo systemctl restart atm-ch`.
