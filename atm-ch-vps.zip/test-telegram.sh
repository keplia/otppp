#!/usr/bin/env bash
# Verify the bot token + destination channel (sends a test msg, then deletes it).
set -euo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")"
if [ -f atm-ch.env ]; then set -a; . ./atm-ch.env; set +a; fi
node atm-ch.mjs --test
