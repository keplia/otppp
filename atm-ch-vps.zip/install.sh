#!/usr/bin/env bash
# ===========================================================================
#  ATM-CH installer — Ubuntu/Debian VPS
#  Installs Node (if needed), deploys to /opt/atm-ch, sets up a systemd
#  service that auto-starts on boot and restarts on crash (24/7).
#
#  Usage:  sudo bash install.sh
# ===========================================================================
set -euo pipefail

APP_DIR=/opt/atm-ch
SERVICE=atm-ch
SVC_FILE="/etc/systemd/system/${SERVICE}.service"
SRC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

c() { printf '\033[1;36m==>\033[0m %s\n' "$*"; }
die() { printf '\033[1;31mERROR:\033[0m %s\n' "$*" >&2; exit 1; }

# --- root / sudo ----------------------------------------------------------
if [ "$(id -u)" -eq 0 ]; then SUDO=""; else SUDO="sudo"; fi

# --- 1. ensure Node >= 18 -------------------------------------------------
need=0
if command -v node >/dev/null 2>&1; then
  major="$(node -v | sed 's/^v//' | cut -d. -f1)"
  [ "$major" -ge 18 ] 2>/dev/null || need=1
else
  need=1
fi
if [ "$need" = "1" ]; then
  c "Installing Node.js 20 (NodeSource)..."
  $SUDO bash -c 'curl -fsSL https://deb.nodesource.com/setup_20.x | bash - && apt-get install -y nodejs'
fi
command -v node >/dev/null 2>&1 || die "node not found after install"
NODE_BIN="$(command -v node)"
c "Node: $NODE_BIN ($(node -v))"

# --- 2. deploy app --------------------------------------------------------
c "Deploying to $APP_DIR"
$SUDO mkdir -p "$APP_DIR"
$SUDO install -m 644 "$SRC_DIR/atm-ch.mjs" "$APP_DIR/atm-ch.mjs"

if [ -f "$APP_DIR/atm-ch.env" ]; then
  c "Keeping existing $APP_DIR/atm-ch.env (not overwritten)"
else
  $SUDO install -m 600 "$SRC_DIR/atm-ch.env" "$APP_DIR/atm-ch.env"
  c "Created $APP_DIR/atm-ch.env"
fi

# --- 3. systemd unit ------------------------------------------------------
c "Writing $SVC_FILE"
$SUDO tee "$SVC_FILE" >/dev/null <<EOF
[Unit]
Description=ATM OTP channel scraper -> Telegram ($SERVICE)
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
WorkingDirectory=$APP_DIR
EnvironmentFile=$APP_DIR/atm-ch.env
ExecStart=$NODE_BIN $APP_DIR/atm-ch.mjs
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
EOF

# --- 4. enable + start ----------------------------------------------------
c "Enabling + starting $SERVICE"
$SUDO systemctl daemon-reload
$SUDO systemctl enable --now "$SERVICE"

sleep 2
$SUDO systemctl --no-pager --full status "$SERVICE" || true

echo
c "Done. Useful commands:"
echo "   sudo systemctl status $SERVICE      # state"
echo "   sudo journalctl -u $SERVICE -f      # live systemd log"
echo "   tail -f $APP_DIR/atm-ch.log         # app log"
echo "   sudo nano $APP_DIR/atm-ch.env       # edit token/filter, then:"
echo "   sudo systemctl restart $SERVICE"
echo "   node $APP_DIR/atm-ch.mjs --test     # (with env) test Telegram"
