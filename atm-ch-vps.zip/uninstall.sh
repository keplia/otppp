#!/usr/bin/env bash
# Remove the atm-ch systemd service (keeps files in /opt/atm-ch).
set -euo pipefail
if [ "$(id -u)" -eq 0 ]; then SUDO=""; else SUDO="sudo"; fi
curl_ok() { :; }
$SUDO systemctl disable --now atm-ch 2>/dev/null || true
$SUDO rm -f /etc/systemd/system/atm-ch.service
$SUDO systemctl daemon-reload
echo "atm-ch service removed. Files kept in /opt/atm-ch (delete manually if wanted)."
